﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace MVCScaffolding03.Models
{
    public class UserDetails
    {
        public int ID { get; set; }

        [StringLength(50)]
        [RegularExpression(Common.DataValidation.CharactersWithSpace, ErrorMessage = "Please enter a valid FirstName")]
        public string FirstName { get; set; }

        [StringLength(50)]
        [RegularExpression(Common.DataValidation.CharactersWithSpace, ErrorMessage = "Please enter a valid LastName")]
        public string LastName { get; set; }

        [StringLength(100)]
        [RegularExpression(Common.DataValidation.Email, ErrorMessage = "Please enter a valid email address")]
        public string EmailAddress { get; set; }

        [StringLength(10)]
        [RegularExpression(Common.DataValidation.NumbersOnly,ErrorMessage="Please enter a valid 10 digit mobile number")]
        public string MobileNo { get; set; }

        public string Status { get; set; }
    }

    public enum StatusType
    {
        Active,
        InActive
    }

    public class UserDBContext : DbContext
    {
        public DbSet<UserDetails> UserDetails { get; set; }
    }
}